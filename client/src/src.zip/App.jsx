import { CircularProgress } from "@mui/material";
import { Suspense } from "react";
import { lazy } from "react";
import { Route, Routes } from "react-router";
import "./App.css";

const Dashboard = lazy(() => import("./Container/Dashboard"));

function App() {
  return (
    <div className="App">
      <Suspense
        fallback={
          <div style={{ textAlign: "center", marginTop: "20%" }}>
            {" "}
            <CircularProgress />
          </div>
        }
      >
        <Routes>
          <Route exact path="/" element={<Dashboard />} />
        </Routes>
      </Suspense>
    </div>
  );
}

export default App;
