import * as types from "./ActionType";

//defining initial state of application
const initialState = {
  accordianId: 0,
};

const DashboardReducer = (state = initialState, action) => {
  switch (action.type) {
    case types.NEXT_ACCORDIAN:
      return {
        ...state,
        accordianId:action.payload,
      };
    case types.UPDATE_ACCORDIAN_ID:
      return {
        ...state,
        accordianId: action.payload,
      };
    case types.PREV_ACCORDIAN:
      return {
        ...state,
        accordianId: action.payload,
      };
    default:
      return state;
  }
};

export default DashboardReducer;
