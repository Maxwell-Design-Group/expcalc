import * as types from "./ActionType";

const updateAccodian = (id) => ({
  type: types.UPDATE_ACCORDIAN_ID,
  payload:id,

});
const next = (id) => ({
  type: types.NEXT_ACCORDIAN,
  payload:id,

});
const prev = (id) => ({
  type: types.PREV_ACCORDIAN,
  payload:id,
});

export const updateAccordianId = (id) => {
  return function (dispatch) {
      dispatch(updateAccodian(id));

  };
};
export const nextAccordianOpen = (id) => {
  return function (dispatch) {
      dispatch(next(id));

  };
};
export const prevAccordianOpen = (id) => {
  return function (dispatch) {
      dispatch(prev(id));

  };
};
