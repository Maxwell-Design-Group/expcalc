import AddCircleIcon from "@mui/icons-material/AddCircle";
import RemoveCircleIcon from "@mui/icons-material/RemoveCircle";
import Accordions from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import Typography from "@mui/material/Typography";
import { useState } from "react";
import { Button, Col, Row } from "react-bootstrap";
import "../../Assets/Style/style.css";
import { useDispatch } from "react-redux";
import { nextAccordianOpen, prevAccordianOpen } from "../../Redux/Actions";
import { useSelector } from "react-redux";
const Step4 = (props) => {
  const tableRows = [];
  const supportingFeatures = [];
  const [checked, setChecked] = useState(false);
  const [expand, setExpand] = useState(false);
  const [featureChecked, setFeatureChecked] = useState(false);
  const [userSelectedProducts, setUserSelectedProducts] = useState([]);
  const [userSelectedFeatures, setUserSelectedFeatures] = useState([]);
  const dispatch = useDispatch();
  const { accordianId } = useSelector((state) => state.Reducer);
  const [tableData, setTabledata] = useState([
    {
      product: "Yokai",
      description: "Lorem ipsum dolor sit amet, consetetur sadipssed",
      cost: "$ 231,453",
    },
    {
      product: "Basil Street",
      description: "Lorem ipsum dolor sit amet, consetetur sadipssed",
      cost: "$ 231,453",
    },
    {
      product: "Enable",
      description: "Lorem ipsum dolor sit amet, consetetur sadipssed",
      cost: "$ 231,453",
    },
    {
      product: "Marko",
      description: "Lorem ipsum dolor sit amet, consetetur sadipssed",
      cost: "$ 231,453",
    },
  ]);
  const supportingFeatureData = [
    {
      label: "Catertrax Catering",
    },
    {
      label: "Catering B2C",
    },
  ];
  const handleChange = (e, rowData, index) => {
    const { checked } = e.target;
    let products = userSelectedProducts;
    if (checked === true) {
      products.push(rowData.product);

      setUserSelectedProducts(products);
    } else {
      for (let i = 0; i < products.length; i++) {
        if (products[i] === rowData.product) {
          console.log("if");
          products.splice(i, 1);

          setUserSelectedProducts(products);
        }
      }
    }
  };
  const handleChangeFeatures = (e, rowData, index) => {
    const { checked } = e.target;
    let features = userSelectedFeatures;
    if (checked === true) {
      features.push(rowData.label);

      setUserSelectedFeatures(features);
    } else {
      for (let i = 0; i < features.length; i++) {
        if (features[i] === rowData.label) {
          console.log("if");
          features.splice(i, 1);

          setUserSelectedFeatures(features);
        }
      }
    }
    console.log("arr ", features);
  };
  tableData.forEach((row, index) => {
    tableRows.push(
      <tr>
        <td>
          <input
            type="checkbox"
            style={{
              accentColor: "#4BAE4F",
              border: "15px solid red",
            }}
            labelStyle={{ color: "white" }}
            iconStyle={{ fill: "white" }}
            defaultChecked={checked}
            name="checkedSacCode"
            id={"theme_check" + index}
            onChange={(e) => handleChange(e, row, index)}
          />
          &nbsp;
          {row.product}
        </td>
        <td>{row.description}</td>
        <td>{row.cost}</td>
      </tr>
    );
  });

  supportingFeatureData.forEach((feature, index) => {
    supportingFeatures.push(
      <div class="fs_button sports" style={{ width: "158px" }}>
        <label>
          <input
            type="checkbox"
            value={feature.label}
            defaultChecked={featureChecked}
            onChange={(e) => handleChangeFeatures(e, feature, index)}
          />
          <span style={{ width: "158px" }}> {feature.label}</span>
        </label>
      </div>
    );
  });
  function onAccordianChange(params) {
    setExpand(!expand);
  }
  const onPrevious = (id) => {
    dispatch(prevAccordianOpen(id));
  };
  const selectNoOption = (id) => {
    dispatch(nextAccordianOpen(id));
  };
  return (
    <div className="stepOne">
      <Row className="pos_row ">
        <div className="pos_container">
          <Row>
            <Col md={3}>
              <div className="pos">
                <span className="pos_label">Digital Sinage</span>
              </div>
            </Col>
            <Col md={9}>
              {" "}
              <div class="ds_btn">
                <span
                  style={{ position: "absolute", top: "-23px", left: "24px" }}
                >
                  50&deg;
                </span>
                <input
                  type="radio"
                  disabled
                  id="a25"
                  name="check-substitution-2"
                  value="Dish $2345"
                />
                <label class="btn btn-default" for="a25">
                  QTY
                </label>
              </div>
              <div class="ds_btn">
                <span
                  style={{ position: "absolute", top: "-23px", left: "24px" }}
                >
                  55&deg;
                </span>
                <input
                  type="radio"
                  disabled
                  id="a50"
                  name="check-substitution-2"
                  value="365 Retail $3445"
                />
                <label class="btn btn-default" for="a50">
                  QTY
                </label>
              </div>
              <div class="ds_btn">
                <span
                  style={{ position: "absolute", top: "-23px", left: "24px" }}
                >
                  65&deg;
                </span>
                <input
                  type="radio"
                  disabled
                  id="a75"
                  name="check-substitution-2"
                  value="Micros $5345"
                />
                <label class="btn btn-default" for="a75">
                  QTY
                </label>
              </div>
            </Col>
          </Row>
        </div>
      </Row>
      <Row className="sf_row">
        <div className="pos_container" style={{ marginBottom: "2em" }}>
          <Row>
            <Col md={3}>
              <div className="pos">
                <span className="pos_label">Catring</span>
              </div>
            </Col>
            <Col md={9}> {supportingFeatures}</Col>
          </Row>
        </div>
      </Row>

      <Row className="rowSeprator" style={{ padding: "0 0.3em" }}>
        <Col md={6} style={{ textAlign: "left" }}>
          <Button
            variant="contained"
            size="small"
            type="submit"
            className="previous_btn"
            onClick={() => onPrevious(accordianId - 1)}
          >
            Previous
          </Button>
        </Col>
        <Col md={6} style={{ textAlign: "right" }}>
          <Button
            variant="contained"
            size="small"
            type="submit"
            className="next_btn"
            onClick={() => selectNoOption(accordianId + 1)}
          >
            Next
          </Button>
        </Col>
      </Row>
    </div>
  );
};

Step4.propTypes = {};

export default Step4;
