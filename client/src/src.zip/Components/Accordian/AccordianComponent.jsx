import React, { useState } from "react";
import Step3 from "./Step3";
import Accordions from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import { Typography } from "@mui/material";
import "../../Assets/Style/accordianStyle.css";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import RemoveCircleIcon from "@mui/icons-material/RemoveCircle";
import { useDispatch, useSelector } from "react-redux";
import { updateAccordianId } from "../../Redux/Actions";
import { useEffect } from "react";
import Step1 from "./Step1";
import Step2 from "./Step2";
import Step5 from "./Step5";
import Step4 from "./Step4";

const AccordianComponent = (props) => {
  const { handleAccordianChange = () => {} } = props;
  const dispatch = useDispatch();
  const { accordianId } = useSelector((state) => state.Reducer);
  const [steps, setSteps] = useState([
    {
      id: 1,
      title: "Tell us about your prospect",
      data: null,

      expanded: false,
      backgroundColor: "#808080",
    },
    {
      id: 2,
      title: "What is important to them?",
      data: null,
      expanded: false,
      backgroundColor: "#000080",
    },
    {
      id: 3,
      title: "How do they envision the dining experience?",
      data: null,
      expanded: false,
      backgroundColor: "#A93226",
    },
    {
      id: 4,
      title: "What additional services will best support this experience?",
      data: null,
      expanded: false,
      backgroundColor: "#16A085",
    },
    {
      id: 5,
      title: "Supporting Question?",
      data: null,
      expanded: false,
      backgroundColor: "#16A085",
    },
  ]);

  const accordianOpen = (accordianId) => {
    handleAccordianChange(accordianId);
    const newState = steps.map((obj) => {
      if (obj.id === accordianId) {
        return { ...obj, expanded: true };
      } else if (obj.id !== accordianId) {
        return { ...obj, expanded: false };
      }
      return obj;
    });

    setSteps(newState);
  };

  const onAccordianChange = (id) => {
    handleAccordianChange(id);
    const newState = steps.map((obj) => {
      if (obj.id === id) {
        if (obj.expanded === true) {
          dispatch(updateAccordianId(0));
          return { ...obj, expanded: false };
        } else {
          dispatch(updateAccordianId(id));
          return { ...obj, expanded: true };
        }
      }
      return obj;
    });

    setSteps(newState);
  };
  useEffect(() => {
    accordianOpen(accordianId);
  }, [accordianId]);
  return (
    <div className="aramark_section stepOne">
      {steps.map((item, index) => (
        <Accordions
          onChange={() => onAccordianChange(item.id)}
          id={"accordian" + item.id}
          expanded={item.expanded}
          className=""
        >
          <AccordionSummary
            expandIcon={
              item.data !== null ? (
                <CheckCircleIcon className="icon_step_complete" />
              ) : item.expanded === true ? (
                <RemoveCircleIcon
                  style={{ margin: "-0.4em 0 0 0 !important" }}
                />
              ) : (
                <AddCircleIcon />
              )
            }
            aria-controls="panel1a-content"
            id="panel1a-header"
            style={{ flexDirection: "row-reverse", margin: "11px 0 0 0" }}
          >
            <Typography>{item.title}</Typography>
          </AccordionSummary>
          <AccordionDetails>
            {item.id === 3 ? (
              <Step3 />
            ) : item.id === 1 ? (
              <Step1 />
            ) : item.id === 2 ? (
              <Step2 />
            ) : item.id === 5 ? (
              <Step5 />
            ) : item.id === 4 ? (
              <Step4 />
            ) : null}
          </AccordionDetails>
        </Accordions>
      ))}
    </div>
  );
};

export default AccordianComponent;
